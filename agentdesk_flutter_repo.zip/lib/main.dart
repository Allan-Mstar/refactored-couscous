import 'package:flutter/material.dart';

void main() {
  runApp(const AgentDeskApp());
}

class AgentDeskApp extends StatelessWidget {
  const AgentDeskApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AgentDesk',
      theme: ThemeData(primarySwatch: Colors.green),
      home: Scaffold(
        appBar: AppBar(title: const Text('AgentDesk Home')),
        body: const Center(child: Text('Welcome, Agent!')),
      ),
    );
  }
}
